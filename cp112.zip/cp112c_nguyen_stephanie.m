f=@(x) log(x)+x^2-3;
a=-1;
b=0;
tol=0.00000005;
c=cp112_nguyen_stephanie_bissection(f,a,b,tol)