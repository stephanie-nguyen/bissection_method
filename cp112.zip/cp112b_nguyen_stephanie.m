f=@(x) sin(x)-6*x-5;
a=-1;
b=0;
tol=0.00000005;
c=cp112_nguyen_stephanie_bissection(f,a,b,tol)