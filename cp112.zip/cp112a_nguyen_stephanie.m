f=@(x) x^5+x-1;
a=0;
b=1;
tol=0.00000005;
c=cp112_nguyen_stephanie_bissection(f,a,b,tol)